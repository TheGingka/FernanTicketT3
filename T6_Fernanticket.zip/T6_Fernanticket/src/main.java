import jdk.jshell.execution.Util;
import models.*;
import models.comunicaciones.Gmail;
import models.comunicaciones.Telegram;
import models.tipo.Admin;
import models.tipo.Tecnico;
import models.tipo.Usuario;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import utils.Menus;
import utils.Persistencia;
import utils.Utils;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Scanner;

public class main {
    public static Scanner s = new Scanner(System.in);
    public static GestionAPP gestionAPP = new GestionAPP();

    // Declaración de email, contraseña.
    public static String email;
    public static String clave;
    public static String clave2;
    // Información para Telegram.
    public static String API = "bot5178503748:AAEXwKV-nR468nDkUFqgDuYe6y4a20tkvys";
    public static String CHATID = "785131120";
    public static void main(String[] args) throws InterruptedException {

        int opcionMenuInicio;

        // Declaración de objetos y usuarios.
        Object userTemp;
        Usuario user;
        Tecnico tech;
        Admin admin;

        // Salida de fecha
        SimpleDateFormat formateadorFecha = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat formateadorHora = new SimpleDateFormat("HH:mm:ss");

        // Declaracion de salidas de menú.

        int opcionMenuUsuario = 0;
        int opcionMenuTecnico = 0;
        int opcionMenuAdmin = 0;



        //INICIO DEL PROGRAMA
        do {

            //Empezamos con el menu de Inicio
            Menus.menuInicio();
            try{
                opcionMenuInicio = Integer.parseInt(s.nextLine());
            }catch (NumberFormatException e){
                System.out.println("No se ha introducido un valor valido");
                opcionMenuInicio = 0;
            }

            switch (opcionMenuInicio) {

                case 1: // Inicio de sesión.

                    do { // Introducir el email.
                        System.out.println("Introduce email: ");
                        email = s.nextLine();
                        if (email.equals("")) System.out.println("Introduce información en el campo.");
                    }while(email.equals(""));


                    do { // Introducir la clave.
                        System.out.println("Introduce clave: ");
                        clave = s.nextLine();

                        if (clave.equals("")) System.out.println("Introduce información en el campo.");
                    }while(clave.equals(""));

                    userTemp = gestionAPP.login(email, clave);

                    if (userTemp != null) { // Comprobación de objetos, admin, tech o usuario.

                        /*
  _    _  _____ _    _         _____  _____ ____
 | |  | |/ ____| |  | |  /\   |  __ \|_   _/ __ \
 | |  | | (___ | |  | | /  \  | |__) | | || |  | |
 | |  | |\___ \| |  | |/ /\ \ |  _  /  | || |  | |
 | |__| |____) | |__| / ____ \| | \ \ _| || |__| |
  \____/|_____/ \____/_/    \_\_|  \_\_____\____/


*/
                        if (userTemp instanceof Usuario) { // Comprobación de objetos, usuario.

                            user = (Usuario) userTemp;
                            if (Persistencia.ultimaVez(user.getNombre()) != null){
                                System.out.println("          ┌──────────────────────────────────────────────────────");
                                System.out.println("          | Usted inicio sesion por ultima vez el " + Persistencia.ultimaVez(user.getNombre()) + " |");
                                System.out.println("          └──────────────────────────────────────────────────────");
                                Persistencia.ultimoInicio(user.getNombre());
                            }else Persistencia.ultimoInicio(user.getNombre());


                            //LOG
                            Persistencia.inicioSesion(user.getNombre());

                            do {

                                Menus.menuUsuario(gestionAPP.incidenciasAbiertasByUsuario(user.getId()), gestionAPP.incidenciasAsignadasByUsuario(user.getId()));

                                do { // Introducir menú usuario.
                                    try{
                                        opcionMenuUsuario = Integer.parseInt(s.nextLine());
                                    }catch (NumberFormatException e){
                                        System.out.println("Introduce una opción válida.");
                                    }
                                    if (opcionMenuUsuario < 1 || opcionMenuUsuario > 6) System.out.println("Introduce una opción disponible.");
                                }while(opcionMenuUsuario < 1 || opcionMenuUsuario > 6);

                                switch (opcionMenuUsuario) {

                                    case 1: //CREAR INCIDENCIA
                                        System.out.println(crearIncidencia(user));
                                        guardarCambiosUsuario(user);
                                        break;

                                    case 2: // Incidencias abiertas en USUARIO.

                                        incidenciasAbiertasDeUsuario(user);
                                        Utils.pausa();
                                        break;

                                    case 3: // Incidencias cerradas de USUARIO.
                                        incidenciasCerradas(user);
                                        Utils.pausa();
                                        break;

                                    case 4: // Muestra la información de USUARIO actual.

                                        System.out.println(user);
                                        Utils.pausa();
                                        break;

                                    case 5: // Cambia la clave de USUARIO.
                                        cambiarContrasena(user);
                                        Utils.pausa();
                                        guardarCambiosUsuario(user);
                                        break;

                                    case 6: // Cerrar sesión de USUARIO.
                                        Utils.cerrarSesion();
                                        Persistencia.cerrarSesion(user.getNombre());
                                        break;

                                    default:
                                        System.out.println("No ha seleccionado ninguna opción de las posibles");
                                }
                            } while (opcionMenuUsuario != 6);
                        } else {

                            /*
  _______ ______ _____ _   _ _____ _____ ____
 |__   __|  ____/ ____| \ | |_   _/ ____/ __ \
    | |  | |__ | |    |  \| | | || |   | |  | |
    | |  |  __|| |    | . ` | | || |   | |  | |
    | |  | |___| |____| |\  |_| || |___| |__| |
    |_|  |______\_____|_| \_|_____\_____\____/


*/
                            if (userTemp instanceof Tecnico) { // Comprobación de objetos, tecnico.

                                tech = (Tecnico) userTemp;
                                if (Persistencia.ultimaVez(tech.getNombre()) != null){
                                    System.out.println("          ┌──────────────────────────────────────────────────────");
                                    System.out.println("          | Usted inicio sesion por ultima vez el " + Persistencia.ultimaVez(tech.getNombre()) + " |");
                                    System.out.println("          └──────────────────────────────────────────────────────");
                                    Persistencia.ultimoInicio(tech.getNombre());
                                }else Persistencia.ultimoInicio(tech.getNombre());

                                do { // Menú de TÉCNICO.

                                Menus.menuTecnico(gestionAPP.incidenciasAbiertasAsignadasByTecnico(tech.getId()), gestionAPP.incidenciasCerradasByTecnico(tech.getId()), gestionAPP.prioridadMediaAppByTecnico(tech.getId()), tech.getNombre());

                                do {
                                    opcionMenuTecnico = Integer.parseInt(s.nextLine());

                                    if (opcionMenuTecnico < 1 || opcionMenuTecnico > 6) System.out.println("Introduce una opción válida.");

                                }while(opcionMenuTecnico < 1 || opcionMenuTecnico > 6);

                                Persistencia.inicioSesion(tech.getNombre());

                                switch (opcionMenuTecnico){

                                    case 1: // Comprobar incidencias asignadas no resueltas en TÉCNICO.
                                        incidenciasTecnicoSinResolver(tech);
                                        break;

                                    case 2: // Marcar una incidencia como resuelta.
                                        marcarIncidenciaComoResuelta(tech);
                                        guardarCambiosTecnico(tech);
                                        break;

                                    case 3: //Consultar mis incidencias cerradas.
                                        consultarIncidenciasCerradas(tech);

                                        Utils.pausa();
                                        break;

                                    case 4: //Mostar datos de tecnico
                                        System.out.println(tech);
                                        Utils.pausa();
                                        break;
                                    case 5: //Cambiar contrasena  de tecnico
                                        cambiarContrasenaTecnio(tech);
                                        guardarCambiosTecnico(tech);
                                        break;

                                    case 6: //Cerrar sesion
                                        Utils.cerrarSesion();
                                        Persistencia.cerrarSesion(tech.getNombre());
                                        break;

                                }
                                }while(opcionMenuTecnico != 6);


                            } else {

                                /*
           _____  __  __ _____ _   _
     /\   |  __ \|  \/  |_   _| \ | |
    /  \  | |  | | \  / | | | |  \| |
   / /\ \ | |  | | |\/| | | | | . ` |
  / ____ \| |__| | |  | |_| |_| |\  |
 /_/    \_\_____/|_|  |_|_____|_| \_|


*/

                                if (userTemp instanceof Admin) { // Comprobación de objetos, admin.
                                    admin = (Admin) userTemp;
                                    if (Persistencia.ultimaVez(admin.getNombre()) != null){

                                        System.out.println("          ┌──────────────────────────────────────────────────────");
                                        System.out.println("          | Usted inicio sesion por ultima vez el " + Persistencia.ultimaVez(admin.getNombre()) + " |");
                                        System.out.println("          └──────────────────────────────────────────────────────");
                                        Persistencia.ultimoInicio(admin.getNombre());
                                    }else Persistencia.ultimoInicio(admin.getNombre());
                                    Persistencia.inicioSesion(admin.getNombre());
                                    do {

                                    Menus.menuAdmin(gestionAPP.incidenciasSinAsignar(), gestionAPP.incidenciasAbiertas(), admin.getNombre());
                                    opcionMenuAdmin = Integer.parseInt(s.nextLine());

                                    switch (opcionMenuAdmin) {

                                        case 1: // Incidencias abiertas GENERALES.
                                            System.out.println("Todas las incidencias abiertas: \n");

                                            for (IncidenciaDataClass i:
                                                    gestionAPP.buscaTodasIncidenciasAbiertas()) {
                                                System.out.println(i.toStringAdmin());
                                            }
                                            Utils.pausa();
                                            break;
                                        case 2: //Incidencias cerradas GENERALES.
                                            incidenciasCerradasGenerales();
                                            Utils.pausa();
                                            break;
                                        case 3: // Busqueda por término.
                                            buscarPorTermino();
                                            break;
                                        case 4: // Información de TECNICO.
                                            mostrarTecnicos();
                                            Utils.pausa();
                                            break;
                                        case 5: // Asignar incidencia a un TECNICO.
                                            asignarIncidencia(admin);
                                            break;

                                        case 6: // Crear un TECNICO.
                                            crearTecnico();
                                            Utils.pausa();
                                            break;

                                        case 7: //Borrar tecnico.
                                            borrarTecnico();
                                            break;

                                        case 8: //Consultar usuarios.
                                            consultarUsuarios();
                                            Utils.pausa();
                                            break;

                                        case 9: //Estadísticas.
                                            Utils.limpiarPantalla();
                                            System.out.println("--- Estadísticas de la aplicación --- ");
                                            System.out.println("|Hay " + gestionAPP.getTecnicos().size()+ " técnicos. \t |");
                                            System.out.println("|Hay " + gestionAPP.getUsuarios().size()+ " usuarios. \t |");
                                            System.out.println("La media de total de incidencias es: " + gestionAPP.prioridadMediaApp());

                                            Utils.pausa();
                                            Utils.limpiarPantalla();
                                            break;

                                        case 10:
                                            Utils.cerrarSesion();
                                            Persistencia.cerrarSesion(admin.getNombre());
                                            break;

                                        case 11:
                                            imprimirProperties();
                                            break;

                                        case 12:
                                            enviarIncidenciasPrendientes();
                                            Utils.limpiarPantalla();
                                            Utils.limpiarPantalla();
                                            break;
                                    }

                                    }while(opcionMenuAdmin != 10);

                                }
                            }
                        }
                    } else {
                        System.out.println("No hay coincidencias.");
                    }
                    break;

                    /*
  _____  ______ _____ _____  _____ _______ _____            _____            _    _  _____ _    _         _____  _____ ____
 |  __ \|  ____/ ____|_   _|/ ____|__   __|  __ \     /\   |  __ \          | |  | |/ ____| |  | |  /\   |  __ \|_   _/ __ \
 | |__) | |__ | |  __  | | | (___    | |  | |__) |   /  \  | |__) |         | |  | | (___ | |  | | /  \  | |__) | | || |  | |
 |  _  /|  __|| | |_ | | |  \___ \   | |  |  _  /   / /\ \ |  _  /          | |  | |\___ \| |  | |/ /\ \ |  _  /  | || |  | |
 | | \ \| |___| |__| |_| |_ ____) |  | |  | | \ \  / ____ \| | \ \          | |__| |____) | |__| / ____ \| | \ \ _| || |__| |
 |_|  \_\______\_____|_____|_____/   |_|  |_|  \_\/_/    \_\_|  \_\          \____/|_____/ \____/_/    \_\_|  \_\_____\____/


*/
                case 2: //Registro con token.

                    do {

                        System.out.println("Introduce email: ");
                        email = s.nextLine();

                        if (!gestionAPP.comprobarEmailUsuario(email))
                            System.out.println("Email ya existente en la base, elija otro.");

                    }while(!gestionAPP.comprobarEmailUsuario(email));

                    int token = generaToken(); // Generamos el token.

                    String mensaje = Gmail.mensaje(token);


                    if (Gmail.enviaMail(email,mensaje,"Token de registro - FernanTicket")){
                        System.out.println("Token enviado con éxito a su correo.");

                    }else System.out.println("Fallo al enviar el token.");

                    System.out.println("Introduce el token enviado al correo: ");
                    int respuestaToken = Integer.parseInt(s.nextLine());


                    if (token != respuestaToken){
                        System.out.println("Token inválido. Vuelva a crear la cuenta.");
                    }else{

                        do {
                            System.out.println("Introduce clave: ");
                            clave = s.nextLine();

                            System.out.println("Introduce clave otra vez: ");
                            clave2 = s.nextLine();

                            if (!gestionAPP.comprobarClave(clave, clave2))
                                System.out.println("Claves diferentes, introduce de nuevo la clave.");
                        } while (!gestionAPP.comprobarClave(clave, clave2));


                        System.out.println("Introduce nombre: ");
                        String nombre = s.nextLine();

                        System.out.println("Introduce apellido: ");
                        String apellido = s.nextLine();

                        System.out.println(gestionAPP.introducirUsuario(nombre, apellido, clave, email) ? "Usuario creado." : "Usuario no creado.");

                    }

                    break;
                default:
                    System.out.println("Introduzca una de las opciones posibles");
                    break;

            }

        } while (opcionMenuInicio != 3);
    }




    /*
   ____ _______ _____             _____        ______ _    _ _   _  _____ _____ ____  _   _ ______  _____
  / __ \__   __|  __ \     /\    / ____|      |  ____| |  | | \ | |/ ____|_   _/ __ \| \ | |  ____|/ ____|
 | |  | | | |  | |__) |   /  \  | (___        | |__  | |  | |  \| | |      | || |  | |  \| | |__  | (___
 | |  | | | |  |  _  /   / /\ \  \___ \       |  __| | |  | | . ` | |      | || |  | | . ` |  __|  \___ \
 | |__| | | |  | | \ \  / ____ \ ____) |      | |    | |__| | |\  | |____ _| || |__| | |\  | |____ ____) |
  \____/  |_|  |_|  \_\/_/    \_\_____/       |_|     \____/|_| \_|\_____|_____\____/|_| \_|______|_____/


*/
    private static void imprimirProperties() {
        try{
            BufferedReader bf = new BufferedReader(new FileReader("./data/Properties/properties.properties"));
            String linea = "";
            while (linea != null){
                System.out.println(linea);
                linea = bf.readLine();
            }
            bf.close();
        }catch (FileNotFoundException e){
            System.out.println("No se encontro el archivo");

        }catch (IOException e){
            System.out.println("No se puede leer el fichero");
        }
    }




/*

  ______ _    _ _   _  _____ _____ ____  _   _ ______  _____         _____  ______       _    _  _____ _    _         _____  _____ ____
 |  ____| |  | | \ | |/ ____|_   _/ __ \| \ | |  ____|/ ____|       |  __ \|  ____|     | |  | |/ ____| |  | |  /\   |  __ \|_   _/ __ \
 | |__  | |  | |  \| | |      | || |  | |  \| | |__  | (___         | |  | | |__        | |  | | (___ | |  | | /  \  | |__) | | || |  | |
 |  __| | |  | | . ` | |      | || |  | | . ` |  __|  \___ \        | |  | |  __|       | |  | |\___ \| |  | |/ /\ \ |  _  /  | || |  | |
 | |    | |__| | |\  | |____ _| || |__| | |\  | |____ ____) |       | |__| | |____      | |__| |____) | |__| / ____ \| | \ \ _| || |__| |
 |_|     \____/|_| \_|\_____|_____\____/|_| \_|______|_____/        |_____/|______|      \____/|_____/ \____/_/    \_\_|  \_\_____\____/



 */
    //Case 1
    private static String crearIncidencia(Usuario user) {
    System.out.println("Introduce el problema: ");
    String descripcion;

    do {
        descripcion = s.nextLine();
        if (descripcion.equals("")) System.out.println("Introduce información.");
    }while(descripcion.equals(""));


    int prioridad; // Introduce la prioridad.

    do {
        System.out.println("Introduce prioridad. Su rango es de [0 - 10]: ");
        prioridad = Integer.parseInt(s.nextLine());

        if (prioridad < 0 || prioridad > 10) System.out.println("Introduce un valor dentro del rango.");

    }while(prioridad < 0 || prioridad > 10);

    if (gestionAPP.insertaIncidencia(descripcion, user.getEmail(), prioridad)) { // Inserta incidencia.
        String mensaje = "El usuario: " + user.getEmail() + " ha insertado una nueva incidencia.";
        Persistencia.nuevaIncidencia(user.getNombre());
        if (Telegram.enviaMensajeTelegram(mensaje, API, CHATID)){
            return ("Incidencia creada correctamente \n" +
                    "Mensaje enviado con éxito.");

        }else return ("Incidencia creada correctamente \n" +
                "Fallo al enviar el mensaje");

    } else {
        System.out.println("Incidencia no subida.");
    }
    return "No se pudo crear la incidencia";
}
    //Case 2
    private static void incidenciasAbiertasDeUsuario(Usuario user) {
    if (user.getIncidencias().size() == 0){
        System.out.println("No hay incidencias abiertas.");
    }else{
        for (IncidenciaDataClass i:
                gestionAPP.buscaIncidenciasSinAsignar()) {
            if (i.getIdUsuario() == user.getId())
                System.out.println(i);
        }
    }

    System.out.println();
}
    //Case 3
    private static void incidenciasCerradas(Usuario user) {
if (gestionAPP.buscaIncidenciasCerradasbyUsuario(user.getId()).size() != 0){
    System.out.println("Incidencias cerradas: ");
    for (IncidenciaDataClass i:
            gestionAPP.buscaIncidenciasCerradasbyUsuario(user.getId())) {
        System.out.println(i);
    }
        }else System.out.println("No tiene ninguna incidencia resuelta");

}
    //Case 5
    private static void cambiarContrasena(Usuario user) {
        System.out.println("Introduce la clave anterior: ");

        String claveantigua;

        do {
            claveantigua = s.nextLine();
            if (claveantigua.equals("")) System.out.println("ERROR. Introduce información en el campo.");
        }while(claveantigua.equals(""));

        System.out.println("Introduce nueva clave: ");
        String clavenueva;

        do {
            clavenueva = s.nextLine();
            if (clavenueva.equals("")) System.out.println("ERROR. Introduce información en el campo.");
        }while(clavenueva.equals(""));


        System.out.println("Introduce nueva clave de nuevo: ");
        String clavenueva2;

        do {
            clavenueva2 = s.nextLine();
            if (clavenueva2.equals("")) System.out.println("ERROR. Introduce información en el campo.");
        }while(clavenueva2.equals(""));

        System.out.println(gestionAPP.cambiaClaveUsuario(claveantigua, clavenueva, clavenueva2) ? "Cambiada con éxito" : "Error en algún parámetro.");

        String mensaje = "El usuario: " + user.getEmail() + " ha cambiado su contraseña.";

        if (Telegram.enviaMensajeTelegram(mensaje, API, CHATID)){
            System.out.println("Mensaje enviado con éxito.");
        }else System.out.println("Fallo para enviar el mensaje.");
    }

    //Guardar cambios
    private static void guardarCambiosUsuario(Usuario user) {
        GestionAPP.guardarCambiosUsuario(user);

    }
    /*


  ______ _    _ _   _  _____ _____ ____  _   _ ______  _____         _____  ______       _______ ______ _____ _   _ _____ _____ ____
 |  ____| |  | | \ | |/ ____|_   _/ __ \| \ | |  ____|/ ____|       |  __ \|  ____|     |__   __|  ____/ ____| \ | |_   _/ ____/ __ \
 | |__  | |  | |  \| | |      | || |  | |  \| | |__  | (___         | |  | | |__           | |  | |__ | |    |  \| | | || |   | |  | |
 |  __| | |  | | . ` | |      | || |  | | . ` |  __|  \___ \        | |  | |  __|          | |  |  __|| |    | . ` | | || |   | |  | |
 | |    | |__| | |\  | |____ _| || |__| | |\  | |____ ____) |       | |__| | |____         | |  | |___| |____| |\  |_| || |___| |__| |
 |_|     \____/|_| \_|\_____|_____\____/|_| \_|______|_____/        |_____/|______|        |_|  |______\_____|_| \_|_____\_____\____/



     */
    //Case 1
    private static void incidenciasTecnicoSinResolver(Tecnico tech) {
        System.out.println("Incidencias asignadas no resueltas: \n");

        for (IncidenciaDataClass i:
                gestionAPP.buscaIncidenciasAbiertasbyTecnico(tech.getId())) {
            System.out.println(i);
        }
    }
    //Case 2
    private static void marcarIncidenciaComoResuelta(Tecnico tech) {
        ArrayList<IncidenciaDataClass> incidenciaResolver = new ArrayList<>(gestionAPP.buscaIncidenciasAbiertasbyTecnico(tech.getId()));

        if (incidenciaResolver.size() == 0){
            System.out.println("No hay incidencias para resolver en este momento. \n");

        }else{

            for (int i = 0; i < incidenciaResolver.size() ; i++) {
                System.out.println((i+1) + " : " + incidenciaResolver.get(i));
            }

            System.out.println("¿Qué incidencia quiere marcar como resuelta?: ");
            int opcionIncidencia;

            do {
                opcionIncidencia = Integer.parseInt(s.nextLine());
                if (opcionIncidencia > incidenciaResolver.size() || opcionIncidencia < 1)
                    System.out.println("Introduce una opción en el rango.");
            }while(opcionIncidencia > incidenciaResolver.size() || opcionIncidencia < 1);


            int idIncidencia = incidenciaResolver.get(opcionIncidencia - 1).getId();

            System.out.println("Introduce la solución al ticket: ");
            String solucion = s.nextLine();

            gestionAPP.cierraIncidencia(idIncidencia,tech.getId(),solucion);
            Persistencia.cerrarIncidencia(tech.getNombre());
            guardarCambiosTecnico(tech);
            String mensaje = "Se ha resuelto la incidencia " + idIncidencia + ", por el técnico: " + tech.getNombre();

            if (Telegram.enviaMensajeTelegram(mensaje, API, CHATID)){
                System.out.println("Mensaje enviado con éxito.");
            }else System.out.println("Fallo para enviar el mensaje.");

        }
    }
    //Case 3
    private static void consultarIncidenciasCerradas(Tecnico tech) {
        if (gestionAPP.buscaIncidenciasCerradassbyTecnico(tech.getId()).size() == 0){
            System.out.println("No ha resuelto ninguna incidencia. \n");
        }else{
            for (IncidenciaDataClass i:
                    gestionAPP.buscaIncidenciasCerradassbyTecnico(tech.getId())) {
                System.out.println(i.toStringTech());
            }
        }
    }
    //Case 5
    private static void cambiarContrasenaTecnio(Tecnico tech) {
        System.out.println("Introduce la clave anaterior: ");
        String claveantigua = s.nextLine();

        System.out.println("Introduce nueva clave: ");
        String clavenueva = s.nextLine();

        System.out.println("Introduce nueva clave de nuevo: ");
        String clavenueva2 = s.nextLine();

        System.out.println(gestionAPP.cambiaClaveTecnico(claveantigua, clavenueva, clavenueva2) ? "Cambiada con éxito" : "Error en algún parámetro.");

        String mensaje = "El técnico: " + tech.getEmail() + " ha cambiado su contraseña.";

        if (Telegram.enviaMensajeTelegram(mensaje, API, CHATID)){
            System.out.println("Mensaje enviado con éxito.");
        }else System.out.println("Fallo para enviar el mensaje.");
    }


    //Guardar cambios
    private static void guardarCambiosTecnico(Tecnico tech) {
        GestionAPP.guardarCambiosTecnico(tech);
    }
/*

  ______ _    _ _   _  _____ _____ ____  _   _ ______  _____         _____  ______                _____  __  __ _____ _   _
 |  ____| |  | | \ | |/ ____|_   _/ __ \| \ | |  ____|/ ____|       |  __ \|  ____|         /\   |  __ \|  \/  |_   _| \ | |
 | |__  | |  | |  \| | |      | || |  | |  \| | |__  | (___         | |  | | |__           /  \  | |  | | \  / | | | |  \| |
 |  __| | |  | | . ` | |      | || |  | | . ` |  __|  \___ \        | |  | |  __|         / /\ \ | |  | | |\/| | | | | . ` |
 | |    | |__| | |\  | |____ _| || |__| | |\  | |____ ____) |       | |__| | |____       / ____ \| |__| | |  | |_| |_| |\  |
 |_|     \____/|_| \_|\_____|_____\____/|_| \_|______|_____/        |_____/|______|     /_/    \_\_____/|_|  |_|_____|_| \_|



 */

    //Case 2
    private static void incidenciasCerradasGenerales() {
        if (gestionAPP.buscaIncidenciasCerradas().size() != 0){
            System.out.println("Todas las incidencias cerradas: ");
            for (IncidenciaDataClass i:
                    gestionAPP.buscaIncidenciasCerradas()) {
                System.out.println(i.toStringAdmin());
            }
        }else System.out.println("No hay ninguna incidencia cerrada");
    }
    //Case 3
    private static void buscarPorTermino() {
        System.out.println("Introduce el termino: ");

        String termino =  s.nextLine();
        termino = termino.toLowerCase();

        for (IncidenciaDataClass i:
                gestionAPP.buscaIncidenciasbyTerm(termino)) {
            System.out.println(i.toStringAdmin());
        }
    }
    //Case 4
    private static void mostrarTecnicos() {
        if (gestionAPP.getTecnicos().size() != 0){
            for (Tecnico t:
                    gestionAPP.getTecnicos()) {
                System.out.println(t);
            }
        }else System.out.println("No hay ningun tecnico creado");
    }
    //Case 5
    private static void asignarIncidencia(Admin admin) {
        int contadorI = 1;
        int contadorT = 1;
        int idIncidencia = 0;
        int idTecnico = 0;
        if (gestionAPP.buscaIncidenciasSinAsignar().size() != 0){
            for (IncidenciaDataClass i:
                    gestionAPP.buscaIncidenciasSinAsignar()) {
                System.out.println(contadorI + ": " + i);
                contadorI++;
            }


            int asignarIncidencia;

            do {
                System.out.println("¿Qué incidencia quiere asignar?: ");
                asignarIncidencia = Integer.parseInt(s.nextLine());
            }while(asignarIncidencia < 1 || asignarIncidencia > gestionAPP.buscaIncidenciasSinAsignar().size());


            for (int i = 0; i < gestionAPP.buscaIncidenciasSinAsignar().size(); i++) {
                if (asignarIncidencia - 1 == i)
                    idIncidencia = gestionAPP.buscaIncidenciasSinAsignar().get(i).getId();
            }
            if (gestionAPP.getTecnicos().size() != 0) {
                for (Tecnico t :
                        gestionAPP.getTecnicos()) {
                    System.out.println(contadorT + ": " + t);
                    contadorT++;
                }

                try{
                    int asignarTecnico;

                    do {
                        System.out.println("¿A qué técnico?: ");
                        asignarTecnico = Integer.parseInt(s.nextLine());
                    } while (asignarTecnico < 1 || asignarTecnico > gestionAPP.getTecnicos().size());

                    for (int i = 0; i < gestionAPP.getTecnicos().size(); i++) {
                        if (asignarTecnico - 1 == i)
                            idTecnico = gestionAPP.getTecnicos().get(i).getId();
                    }
                }catch (NumberFormatException e){
                    System.out.println("No ha seleccionado uno posible");
                }


                int idUser = gestionAPP.buscaIncidenciaUsuario(idIncidencia);
                gestionAPP.asignaIncidencia(idIncidencia, idTecnico);

                Persistencia.asignacionIncidencia(admin.getNombre());
                String mensaje = "Se ha asignado la incidencia " + idIncidencia + ", al tecnico: " + gestionAPP.buscaTecnico(idTecnico).getEmail() + ".";
                guardarCambiosUsuario(gestionAPP.buscaUsuariobyID(idUser));
                guardarCambiosTecnico(gestionAPP.buscaTecnico(idTecnico));
                if (Telegram.enviaMensajeTelegram(mensaje, API, CHATID)) {
                    System.out.println("Mensaje enviado con éxito.");
                } else System.out.println("Fallo para enviar el mensaje.");
            }else System.out.println("No hay ningun tecnico creado");;
        }else System.out.println("No hay incidencias para asignar");

    }
    //Case 6
    private static void crearTecnico() {
        String email = "", clave = "", clave2 = "", mensaje = "";
        System.out.println("Creación de perfil tecnico.");

        do {

            System.out.println("Introduce email: ");
            email = s.nextLine();

            if (!gestionAPP.comprobarEmailTecnico(email))
                System.out.println("Email ya existente en la base, elija otro.");

        }while(!gestionAPP.comprobarEmailUsuario(email));


        do {
            System.out.println("Introduce clave: ");
            clave = s.nextLine();

            System.out.println("Introduce clave otra vez: ");
            clave2 = s.nextLine();

            if (!gestionAPP.comprobarClave(clave, clave2))
                System.out.println("Claves diferentes, introduce de nuevo la clave.");
        } while (!gestionAPP.comprobarClave(clave, clave2));


        System.out.println("Introduce nombre: ");
        String nombre = s.nextLine();

        System.out.println("Introduce apellido: ");
        String apellido = s.nextLine();

        System.out.println(gestionAPP.introducirTecnico(nombre, apellido, clave, email) ? "Tecnico creado." : "Tecnico no creado.");

        mensaje = "Se ha creado un nuevo técnico, con email: " + email;

        if (Telegram.enviaMensajeTelegram(mensaje, API, CHATID)){
            System.out.println("Mensaje enviado con éxito.");
        }else System.out.println("Fallo para enviar el mensaje.");
    }
    //Case 7
    private static void borrarTecnico() {
        int contadorTecnicos = 1;
        if (gestionAPP.getTecnicos().size() != 0){
            for (Tecnico t:
                    gestionAPP.getTecnicos()) {
                System.out.println(contadorTecnicos + ":" + t);
                contadorTecnicos++;
            }

            System.out.println("¿Qué técnico desea borrar?: ");
            try{
                int deleteTecnico = Integer.parseInt(s.nextLine());
                if (deleteTecnico < gestionAPP.getTecnicos().size() && deleteTecnico > 0) {
                    System.out.println(gestionAPP.sePuedeBorrarTecnico(gestionAPP.getTecnicos().get(deleteTecnico - 1).getId()));
                    if (gestionAPP.sePuedeBorrarTecnico(gestionAPP.getTecnicos().get(deleteTecnico - 1).getId())) {
                        System.out.println("Este técnico se borrará.");
                        Utils.cargando();
                        System.out.println("Tecnico borrado correctamente");
                        Utils.pausa();
                        //Incluir lo de eliminar de persistencia
                        gestionAPP.eliminarTecnico(gestionAPP.getTecnicos().get(deleteTecnico - 1));
                        gestionAPP.borrarTecnico(gestionAPP.getTecnicos().get(deleteTecnico - 1).getId());

                    } else {
                        System.out.println("Este técnico no puede borrarse porque tiene incidencias resueltas o asignadas");
                    }
                }else System.out.println("No selecciono una opcion posible");
            }catch (NumberFormatException | InterruptedException e){
                System.out.println("No ha introducido una valor correcto");
            }

        }else System.out.println("No hay tecnicos disponibles para eliminar");

    }
    //Case 8
    private static void consultarUsuarios() {
        if (gestionAPP.getUsuarios().size() != 0){
            for (Usuario u:
                    gestionAPP.getUsuarios()) {
                System.out.println(u);
            }
        }else System.out.println("No hay usuarios creados");;

    }
    //Case 12
    private static void enviarIncidenciasPrendientes() {
        int contadorTecnicos = 1;
        if (gestionAPP.getTecnicos().size() != 0) {
            if (gestionAPP.getTecnicos().size() != 0 && gestionAPP.tecnicosConIncidenciasAbiertas().size() != 0) {
                for (Tecnico t :
                        gestionAPP.tecnicosConIncidenciasAbiertas()) {
                    System.out.println(contadorTecnicos + ":" + t);
                    contadorTecnicos++;
                }
                System.out.println("¿Que tecnico desea enviarle sus incidencias pendientes?: ");
                try {
                    int seleccionTecnico = Integer.parseInt(s.nextLine());
                    if (seleccionTecnico < gestionAPP.tecnicosConIncidenciasAbiertas().size() + 1 && seleccionTecnico > 0){
                        System.out.println("hola");
                        Tecnico temp = gestionAPP.tecnicosConIncidenciasAbiertas().get(seleccionTecnico - 1);
                        enviarIncidencias(temp);
                    } else System.out.println("No ha introducido un tecnico posible.");

                } catch (NumberFormatException  e) {
                    System.out.println("No ha introducido una valor correcto.");
                }

            } else System.out.println("No hay tecnicos disponibles para enviar incidencias.");
        }else{
            System.out.println("No hay ningun tecnico creado.");
            Utils.pausa();
        }
    }

    private static void enviarIncidencias(Tecnico temp) {
        crearExcel(temp);
        Gmail.enviaMailExcel(temp.getEmail(), "Incidencias abiertas por resolver, adjuntas en el correo. ", "Incidencias de FernanTicket");
    }


    private static void guardarCambiosAdmin(Admin admin) {
        System.out.println(admin);
        Persistencia.saveObjectUser(gestionAPP.buscaUsuario(admin.getEmail()));
    }




    /*

  _____  ______ _____ _____  _____ _______ _____   ____
 |  __ \|  ____/ ____|_   _|/ ____|__   __|  __ \ / __ \
 | |__) | |__ | |  __  | | | (___    | |  | |__) | |  | |
 |  _  /|  __|| | |_ | | |  \___ \   | |  |  _  /| |  | |
 | | \ \| |___| |__| |_| |_ ____) |  | |  | | \ \| |__| |
 |_|  \_\______\_____|_____|_____/   |_|  |_|  \_\\____/


     */

    public static int generaToken(){

        return (int) (Math.random()*100);

    }


    //EXCEL
    public static void crearExcel(Tecnico temp){
        Workbook book = new XSSFWorkbook();
        Sheet sheet = book.createSheet("Incidencias");

        Row row = sheet.createRow(0);
        row.createCell(0).setCellValue("Incidencias");
        row.createCell(1).setCellValue("Incidencia con ID");
        row.createCell(2).setCellValue("Comentario del usuario");
        row.createCell(3).setCellValue("Prioridad");
        row.createCell(4).setCellValue("Fecha de inicio");
        row.createCell(5).setCellValue("Días desde su creación");


        int x = 0;

        for (Incidencia i:
                temp.getIncidencias()) {
            if (!i.isEstaResuelta()) {
                    x++;
                    Row rowe = sheet.createRow(x);
                    rowe.createCell(0).setCellValue("Incidencias " + x);
                    rowe.createCell(1).setCellValue(String.valueOf(i.getId()));
                    rowe.createCell(2).setCellValue(String.valueOf(i.getDescripcion()));
                    rowe.createCell(3).setCellValue(String.valueOf(i.getPrioridad()));
                    rowe.createCell(4).setCellValue(String.valueOf(i.getFechaInicio()));
                    rowe.createCell(5).setCellValue("0");
            }
        }


        try{
            FileOutputStream fileout = new FileOutputStream("Excel.xlsx");
            book.write(fileout);

            fileout.close();
        } catch (IOException e){
            System.out.println("No se pudo crear.");
        }


    }



}
