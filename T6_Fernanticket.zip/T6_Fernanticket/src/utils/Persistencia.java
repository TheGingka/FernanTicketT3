package utils;

import models.tipo.Admin;
import models.tipo.Tecnico;
import models.tipo.Usuario;

import java.io.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Properties;

public class Persistencia {

    //Salida de fecha

    static DateTimeFormatter f = DateTimeFormatter.ofPattern("hh:mm:ss");

    //USUARIO
    public static void saveObjectUser(Usuario u){ // Guarda el objeto USUARIO.

        try{

            FileOutputStream fos = new FileOutputStream("./data/Usuarios/" + u.getId() + ".user");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(u);
            oos.close();

        }catch (Exception e){
            e.fillInStackTrace();
        }

    }

    public static ArrayList<Usuario> readObjectUser(){ // Lee el objeto USUARIO.

        File fichero = new File("./data/Usuarios/");
        String [] listaFicheros = fichero.list();
        ArrayList<Usuario> listaUsuarios = new ArrayList();

        if (listaFicheros != null){
            for (String s:
                    listaFicheros) {
                try{
                    FileInputStream fis = new FileInputStream("./data/Usuarios/" + s);
                    ObjectInputStream ois = new ObjectInputStream(fis);
                    Usuario u = (Usuario) ois.readObject();
                    listaUsuarios.add(u);
                    ois.close();

                }catch (Exception e){
                    e.fillInStackTrace();
                }
            }
        }
        return listaUsuarios;

    }


    //TECNICO
    public static void saveObjectTech(Tecnico t){ //Guardar Tecnico

        try{

            FileOutputStream fos = new FileOutputStream("./data/Tecnicos/" + t.getId() + ".tech");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(t);
            oos.close();

        }catch (Exception e){
            e.fillInStackTrace();
        }

    }

    public static ArrayList<Tecnico> readObjectTech(){  //Recuperar Tecnico

        File fichero = new File("./data/Tecnicos/");
        String [] listaFicheros = fichero.list();
        ArrayList<Tecnico> listaTecnicos = new ArrayList();

        if (listaFicheros != null){
            for (String s:
                    listaFicheros) {
                try{
                    FileInputStream fis = new FileInputStream("./data/Tecnicos/" + s);
                    ObjectInputStream ois = new ObjectInputStream(fis);
                    Tecnico t = (Tecnico) ois.readObject();
                    listaTecnicos.add(t);
                    ois.close();

                }catch (Exception e){
                    e.fillInStackTrace();
                }
            }
        }
        return listaTecnicos;

    }

    //ADMIN


    public static void deleteTech(Tecnico t){ //Eliminar tecnico

        File fichero = new File("./data/Tecnicos/" + t.getId() + ".tech");
        if (fichero.exists()) fichero.delete();

    }

    public static void saveObjectAdmin(Tecnico t){

        try{

            FileOutputStream fos = new FileOutputStream("./data/Admins/" + t.getId() + ".admin");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(t);
            oos.close();

        }catch (Exception e){
            e.fillInStackTrace();
        }

    }

    public static ArrayList<Admin> readObjectAdmin(){

        File fichero = new File("./data/Admins/");
        String [] listaFicheros = fichero.list();
        ArrayList<Admin> listaAdmins = new ArrayList();

        if (listaFicheros != null){
            for (String s:
                    listaFicheros) {
                try{
                    FileInputStream fis = new FileInputStream("./data/Admins/" + s);
                    ObjectInputStream ois = new ObjectInputStream(fis);
                    Admin a = (Admin) ois.readObject();
                    listaAdmins.add(a);
                    ois.close();

                }catch (Exception e){
                    e.fillInStackTrace();
                }
            }
        }
        return listaAdmins;

    }

    // LOG

    public static void inicioSesion(String nombre){     //Guardar Inicio de sesion

        String mensajeLog = "- Inicio de sesión;  ";
        mensajeLog += nombre + ";  ";
        mensajeLog += String.valueOf(LocalDate.now()) + ";  ";
        mensajeLog += String.valueOf(LocalTime.now()) + "  ";
        mensajeLog += " - ";

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("./data/Log/log" , true));
            bw.write("\n" + mensajeLog);
            bw.close();

        } catch (IOException ioe) {
            System.out.println("No se ha podido escribir en el fichero.");
        }

    }

    public static void cerrarSesion (String nombre){     //Guardar Inicio de sesion

        String mensajeLog = "- Cierre de sesión;  ";
        mensajeLog += nombre + ";  ";
        mensajeLog += LocalDate.now() + ";  ";
        mensajeLog += LocalTime.now() + "  ";
        mensajeLog += " - ";

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("./data/Log/log" , true));
            bw.write("\n" + mensajeLog);
            bw.close();

        } catch (IOException ioe) {
            System.out.println("No se ha podido escribir en el fichero.");
        }

    }

    public static void nuevaIncidencia(String nombre ) {
        String mensajeLog = "- Nueva incidencia;  ";
        mensajeLog += nombre + ";  ";
        mensajeLog += String.valueOf(LocalDate.now()) + ";  ";
        mensajeLog += String.valueOf(LocalTime.now()) + "  ";
        mensajeLog += " - ";

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("./data/Log/log" , true));
            bw.write("\n" + mensajeLog);
            bw.close();

        } catch (IOException ioe) {
            System.out.println("No se ha podido escribir en el fichero.");
        }
    }

    public static void cerrarIncidencia(String nombre){     //Guardar Inicio de sesion

        String mensajeLog = "- Incidencia cerrada;  ";
        mensajeLog += nombre + ";  ";
        mensajeLog += String.valueOf(LocalDate.now()) + ";  ";
        mensajeLog += String.valueOf(LocalTime.now()) + "  ";
        mensajeLog += " - ";

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("./data/Log/log" , true));
            bw.write("\n" + mensajeLog);
            bw.close();

        } catch (IOException ioe) {
            System.out.println("No se ha podido escribir en el fichero.");
        }

    }

    public static void asignacionIncidencia(String nombre){     //Guardar Inicio de sesion

        String mensajeLog = "- Asignacion de incidencia;  ";
        mensajeLog += nombre + ";  ";
        mensajeLog += String.valueOf(LocalDate.now()) + ";  ";
        mensajeLog += String.valueOf(LocalTime.now()) + "  ";
        mensajeLog += " - ";

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("./data/Log/log" , true));
            bw.write("\n" + mensajeLog);
            bw.close();

        } catch (IOException ioe) {
            System.out.println("No se ha podido escribir en el fichero.");
        }

    }

    public static void ultimoInicio(String nombre){
        String mensajeLog = "";
        mensajeLog += LocalDate.now() + ";  ";
        mensajeLog += LocalTime.now() + "  ";
        try{
            Properties properties = new Properties();
            FileInputStream file = new FileInputStream("./data/Properties/properties.properties");
            properties.load(file);
            if (properties.containsKey(nombre)){
                properties.setProperty(nombre , mensajeLog);
            }else properties.put(nombre , mensajeLog);
            properties.store(new FileWriter("./data/Properties/properties.properties") , null);
        }catch (FileNotFoundException e){
            System.out.println("No se encontro el archivo");

        }catch (IOException e){
            System.out.println("No se puede leer el fichero");
        }
    }

    public static String ultimaVez(String nombre) {
        try {
        Properties properties = new Properties();
        FileInputStream file = new FileInputStream(new File("./data/Properties/properties.properties"));
        properties.load(file);
        if (properties.containsKey(nombre)){
            return properties.getProperty(nombre);
        }else return null;
        }catch (FileNotFoundException e){
            System.out.println("No se encontro el archivo");

        }catch (IOException e){
            System.out.println("No se puede leer el fichero");
        }
        return null;
    }
}
